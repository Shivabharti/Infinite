package com.java.ims;

import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.naming.NamingException;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;


public class EjbImpl {

	SessionFactory sf;
	Session session;

	public List<Customer_Details> showCustomer() throws NamingException {
		CustomerBeanRemote remote = RemoteHelper.lookupRemoteStatelessCustomer();
		return remote.showCustomer();
	}

	public List<Insurance_Details> showInsurance() {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Insurance_Details.class);
		List<Insurance_Details> insList = cr.list();
		return insList;
	}

	public Insurance_Details getInsurance(String insuranceId) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Insurance_Details.class);
		cr.add(Restrictions.eq("insuranceId", insuranceId));
		Insurance_Details inssu = (Insurance_Details) cr.uniqueResult();
		return inssu;
	}

	public String addCustomer(Customer_Details cust) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		String encr = EncryptPassword.getCode(cust.getPassCode());
		cust.setPassCode(encr);
		session.save(cust);
		session.getTransaction().commit();

		int otp = GenerarteOtp.generateOtp();

		String subject = "Welcome to life Insurance";
		String messageText = "Hello,\\n\\nThank you for signing up in our LicApp. Your otp is \"+otp+\"It is \"\r\n"
				+ "				+ \"valid for 10 minuetes only dont share your  otp with others";
		MailSend.mailSend(cust.getEmail(), subject, messageText);

		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans1 = session.beginTransaction();
		Customer_Authorization custAuth = new Customer_Authorization();
		custAuth.setCust_ID(cust.getCust_ID());
		custAuth.setOtp(otp);
		session.getTransaction().commit();
		return "CustomerAuth.jsp?faces-redirect=true";
	}
	
	public String verifyOtp(Customer_Authorization customerA) {
		SessionFactory sf= SessionHelper.getConnection();
		Session session=sf.openSession();
		Criteria cr=session.createCriteria(Customer_Details.class);
		cr.add(Restrictions.eq("name", customerA.getCust_ID()));
		cr.add(Restrictions.eq("Otp", customerA.getOtp()));
		cr.setProjection(Projections.rowCount());
		long count=(long)cr.uniqueResult();
		System.out.println(count);
		
		if(count==1) {
			int pid=customerA.getAuth_ID();
			Map<String,Object>sessionMap=FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
			sessionMap.put("pid",pid);
			return"ResetPassWord.jsp?faces-redirect=true";
		}else {
			
			return "OTPVerification.jsp?faces-redirect=true";
		}
		
	}

	public Customer_Details getMailId(String custId) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Customer_Details.class);
		cr.add(Restrictions.eq("custId", custId));
		Customer_Details cust = (Customer_Details) cr.uniqueResult();

		return cust;
	}

	public Customer_Authorization getOtp(String custId) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Customer_Authorization.class);
		cr.add(Restrictions.eq("custId", custId));
		Customer_Authorization custA = (Customer_Authorization) cr.uniqueResult();

		return custA;
	}

	public String addAuthorization(Customer_Authorization custAutho) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();

		Customer_Authorization customer_Auth = getOtp(custAutho.getCust_ID());
		Customer_Details customer = getMailId(custAutho.getCust_ID());

		int otpTable = customer_Auth.getOtp();

		if (otpTable == custAutho.getOtp()) {
			String email = customer.getEmail();
			String subject = "Welcome to Life Insurance";
			String messageText = "Hello,\\n\\n Your account has been successfully created.Congragulation you are now goldmember";

			MailSend.mailSend(email, subject, messageText);

			return "ResetPassWord.jsp?faces-redirect=true";
		} else {
			return "CustomerAuth.jsp?faces-redirect=true";
		}
	}

	public String resetPassWord(Customer_Details cust) {

		Customer_Details custp = getMailId(cust.getCust_ID());
		String pass1 = cust.getPassCode();
		String pass2 = cust.getReTypePassCode();
		if (pass1.equals(pass2)) {
			sf = SessionHelper.getConnection();
			session = sf.openSession();
			Transaction trans = session.beginTransaction();
			String encr = EncryptPassword.getCode(cust.getPassCode());
			custp.setPassCode(encr);
			custp.setReTypePassCode(encr);
			custp.setStatus("Active");
			session.update(custp);
			session.getTransaction().commit();
			return "LoginCustomer.jsp?faces-redirect=true";
		} else {
			return "ResetPassWord.jsp?faces-redirect=true";

		}
	}

	public String LoginCustomer(Customer_Details customer) {
		String encr = EncryptPassword.getCode(customer.getPassCode());
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Customer_Details.class);
		cr.add(Restrictions.eq("userName", customer.getUserName()));
		cr.add(Restrictions.eq("passCode", customer.getPassCode()));
		cr.setProjection(Projections.rowCount());
		long count = (Long) cr.uniqueResult();
		if (count == 1) {
			return "Dashboard.jsp?faces-redirect=true";
		} else {
			return "LoginCustomer.jsp?faces-redirect=true";
		}

	}

	public String addCustomerPolicy(CustomerPolicy policy) {
//		Insurance insFound=getInsurance(policy.getInsuranceId());
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		if (policy.getPayMode().equals("MONTHLY")) {
			double amount = policy.getInsuranceAmount();
			double price = (amount / 12);
			policy.setInitialAmount(price);
			session.save(policy);
			session.getTransaction().commit();
		} else if (policy.getPayMode().equals("QUARTERLY")) {
			double amount = policy.getInsuranceAmount();
			double price = (amount / 4);
			policy.setInitialAmount(price);
			session.save(policy);
			session.getTransaction().commit();

		} else if (policy.getPayMode().equals("HALFYEARLY")) {
			double amount = policy.getInsuranceAmount();
			double price = (amount / 2);
			policy.setInitialAmount(price);
			session.save(policy);
			session.getTransaction().commit();
		} else if (policy.getPayMode().equals("YEARLY")) {

			policy.setInitialAmount(policy.getInsuranceAmount());
			session.save(policy);
			session.getTransaction().commit();
		}
		return "ShowCustomerPolicy.jsp?faces-redirect=true";
	}

	public List<Insurance_Details> getListOfInsurance(int firstRow, int rowCount) {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		List<Insurance_Details> cdList = null;
		session.beginTransaction();
		Criteria criteria = session.createCriteria(Insurance_Details.class);
		criteria.setFirstResult(firstRow);
		criteria.setMaxResults(rowCount);
		return criteria.list();
	}

	public int countRows() {
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		try {
			session.beginTransaction();
			Criteria criteria = session.createCriteria(Insurance_Details.class);
			if (criteria != null) {
				return criteria.list().size();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
