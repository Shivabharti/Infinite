package com.java.HMS1;

import java.util.List;

public interface DoctorDAO {

	List<Doctor_Master> showDoctorDao();

}
