package com.java.HMS1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class PatientDaoImpl {
	public static int generateOtp() {
		Random r = new Random( System.currentTimeMillis() );
	    return ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
	}
	SessionFactory sf;
	Session session;
	public String AddPatient(Patient_Master patient) {
		sf=SessionHelper.getConnection();
		session=sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(patient);
		transaction.commit();
		
		int otp = GenerateOtp.generateOtp();
		String body ="Welcome to Mr/Miss  " +patient.getName() + "\r\n"+
				"Your OTP Generated Successfully..." +"\r\n" + 
				"OTP is " +otp;
		MailSend.mailOtp(patient.getEmail(), "Otp Send Succesfully...", body);
		return "User Created Successfully...";
	} else {
	// TODO Auto-generated method stub
	return "User-Name already Exists...";
	}
	}}