package com.java.HMS1;

import java.util.List;

public interface RoomDAO {

	List<Room_Master> showRoomDao();

}
