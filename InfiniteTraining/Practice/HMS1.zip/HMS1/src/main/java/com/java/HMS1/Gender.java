package com.java.HMS1;

public enum Gender {
	M, F
}
