package com.java.CMS;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class RestaurantDAOImpl {
	SessionFactory sf;
	Session session;

	public List<Restaurant> showRestDao() {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Restaurant.class);
		return cr.list();
	}
}
