package com.java.CMS;

public class Restaurant {

	private int restaurant_Id;
	private String restaurant_name;
	private String branch;
	private String city;
	private String email;
	private String rating;
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getRestaurant_Id() {
		return restaurant_Id;
	}
	public void setRestaurant_Id(int restaurant_Id) {
		this.restaurant_Id = restaurant_Id;
	}
	public String getRestaurant_name() {
		return restaurant_name;
	}
	public void setRestaurant_name(String restaurant_name) {
		this.restaurant_name = restaurant_name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public Restaurant(int restaurant_Id, String restaurant_name, String branch, String city, String email,
			String rating, String mobileNo) {
		super();
		this.restaurant_Id = restaurant_Id;
		this.restaurant_name = restaurant_name;
		this.branch = branch;
		this.city = city;
		this.email = email;
		this.rating = rating;
		this.mobileNo = mobileNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public Restaurant() {
		super();
		// TODO Auto-generated constructor stub
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	private String mobileNo;
	
	
	
}
